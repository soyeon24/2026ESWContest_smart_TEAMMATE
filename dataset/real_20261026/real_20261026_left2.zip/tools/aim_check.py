"""Live setup check before recording (2026-10-26, PC/coordinator criteria).

    python -X utf8 aim_check.py          # every second until Ctrl+C
    python -X utf8 aim_check.py 5        # five lines

Per sensor: which columns / rows hold the person (cells 150~1200 mm), the body distance, and the head share
(near cells in rows 0~1). Then the board's own posture. Good upright setup (10-19 reference): body ~0.75~0.80 m,
head share >= ~0.3 (10-19: 0.39; the bad left recording had 0.14), board says upright.
"""
import json
import statistics as st
import sys
import time
import urllib.request

HOST = "172.20.10.3"
N = int(sys.argv[1]) if len(sys.argv) > 1 else 0


def get(url):
    return json.loads(urllib.request.urlopen(url, timeout=1).read().decode())


i = 0
while N == 0 or i < N:
    i += 1
    try:
        raw = get(f"http://{HOST}:8772/raw")
        out = []
        for s in raw.get("sensors", []):
            D, S = s.get("dist_mm", []), s.get("status", [])
            ok = [S[k] in (5, 9) and 150 < D[k] < 1200 for k in range(64)]
            cols = "".join("#" if sum(ok[r * 8 + c] for r in range(8)) >= 3 else ("+" if any(ok[r * 8 + c] for r in range(8)) else ".") for c in range(8))
            rows = "".join(str(min(9, sum(ok[r * 8:(r + 1) * 8]))) for r in range(8))
            near = [D[k] for k in range(64) if ok[k]]
            head = sum(ok[:16]) / 16
            dist = f"{st.median(near) / 1000:.2f}m" if near else "-"
            out.append(f"{'A' if s.get('id') == 0 else 'B'} 열[{cols}] 행(위→아래)[{rows}] 몸 {dist} 머리 {head:.2f}")
        try:
            stt = get(f"http://{HOST}:8771/api/state")
            board = f"보드: {stt.get('posture')} {float(stt.get('conf') or 0):.2f}"
        except Exception:
            board = "보드: -"
        print(" | ".join(out) + " | " + board, flush=True)
    except Exception as e:
        print("…", e, flush=True)
    time.sleep(1)
