"""Record the Pi 4 ToF stream from the laptop while the hub owns the ESP32 serial port (2026-10-26).

    python record_board.py --host 172.20.10.3 --out ../front_75cm/rec

Polls GET :8772/raw (both VL53L8CX sensors, newest 0x05 frame each) and GET :8771/api/state (board posture
service judgment) at --hz, and writes three files next to --out:

  <out>_raw.jsonl     verbatim: {"host_t": epoch_s, "kind": "raw", "dev": ..., "sensor": {...as /raw gives it...}}
                      one line per NEW frame per sensor (dedup by frame_seq), plus {"kind": "state", ...} lines
  <out>_toflines.jsonl  tof_live --record wrapper so real_from_record.py reads it unchanged:
                      {"host_t": t, "port": "S0"|"S1", "raw": "F,<ts_ms>,<64 dist>,<64 status>"}
                      dist_mm is already oriented by the firmware (0x05 flags: flip_rows=true, flip_cols=false)
                      -> score with no extra flip.
  <out>_status.txt    rolling frame counts (rewritten every 5 s) so the guide/operator can see it is alive.

Ctrl+C stops. Standard library only.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import urllib.request


def get_json(url: str, timeout: float):
    with urllib.request.urlopen(url, timeout=timeout) as r:  # noqa: S310 - local board
        return json.loads(r.read().decode("utf-8"))


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--host", default="172.20.10.3")
    ap.add_argument("--out", required=True, help="path prefix, e.g. ../front_75cm/rec")
    ap.add_argument("--hz", type=float, default=10.0)
    ap.add_argument("--timeout", type=float, default=1.0)
    ap.add_argument("--seconds", type=float, default=0, help="stop after this many seconds (0 = until Ctrl+C / killed)")
    args = ap.parse_args()

    os.makedirs(os.path.dirname(os.path.abspath(args.out)) or ".", exist_ok=True)
    raw_url = f"http://{args.host}:8772/raw"
    state_url = f"http://{args.host}:8771/api/state"
    f_raw = open(args.out + "_raw.jsonl", "a", encoding="utf-8")
    f_tof = open(args.out + "_toflines.jsonl", "a", encoding="utf-8")
    status_path = args.out + "_status.txt"

    last_seq: dict[int, int] = {}
    counts = {0: 0, 1: 0}
    window = {0: 0, 1: 0}
    states = 0
    errors = 0
    last_err = ""
    t_start = time.time()
    t_status = t_start
    period = 1.0 / args.hz
    next_t = time.monotonic()
    print(f"recording {raw_url} + {state_url} -> {args.out}_*.jsonl  (Ctrl+C to stop)", flush=True)
    try:  # PC scorer (tools/real-scoring-1026): one line with the model's orientation flags at the start
        model = (get_json(state_url, 2.0) or {}).get("model") or {}
        f_raw.write(json.dumps({"host_t": round(time.time(), 4), "kind": "meta", "flip_rows": model.get("flip_rows"),
                                "flip_cols": model.get("flip_cols"), "model": model}, separators=(",", ":")) + "\n")
    except Exception as exc:
        print(f"meta line failed: {exc}", flush=True)
    try:
        while True:
            now = time.time()
            if args.seconds and now - t_start >= args.seconds:
                break
            try:
                raw = get_json(raw_url, args.timeout)
                for s in raw.get("sensors", []):
                    sid = int(s.get("id", -1))
                    if not s.get("have") or "dist_mm" not in s:
                        continue
                    seq = s.get("frame_seq")
                    if last_seq.get(sid) == seq:
                        continue
                    last_seq[sid] = seq
                    f_raw.write(json.dumps({"host_t": round(now, 4), "kind": "raw", "dev": raw.get("dev"), "sensor": s},
                                           separators=(",", ":")) + "\n")
                    line = "F,%d,%s,%s" % (int(s.get("ts_ms", 0)), ",".join(str(int(v)) for v in s["dist_mm"]),
                                           ",".join(str(int(v)) for v in s.get("status", [])))
                    f_tof.write(json.dumps({"host_t": round(now, 4), "port": f"S{sid}", "raw": line},
                                           separators=(",", ":")) + "\n")
                    counts[sid] = counts.get(sid, 0) + 1
                    window[sid] = window.get(sid, 0) + 1
            except Exception as exc:  # board hiccup: keep going, count it
                errors += 1
                last_err = f"raw: {exc}"
            try:
                st = get_json(state_url, args.timeout)
                f_raw.write(json.dumps({"host_t": round(now, 4), "kind": "state", "state": st},
                                       separators=(",", ":")) + "\n")
                states += 1
            except Exception as exc:
                errors += 1
                last_err = f"state: {exc}"
            if now - t_status >= 5.0:
                f_raw.flush()
                f_tof.flush()
                dt = now - t_status
                with open(status_path, "w", encoding="utf-8") as fp:
                    fp.write(f"t={now:.1f} elapsed={now - t_start:.0f}s "
                             f"S0={counts.get(0, 0)} ({window.get(0, 0) / dt:.1f} Hz) "
                             f"S1={counts.get(1, 0)} ({window.get(1, 0) / dt:.1f} Hz) "
                             f"states={states} errors={errors} {last_err}\n")
                window = {0: 0, 1: 0}
                t_status = now
            next_t += period
            delay = next_t - time.monotonic()
            if delay > 0:
                time.sleep(delay)
            else:
                next_t = time.monotonic()
    except KeyboardInterrupt:
        pass
    finally:
        f_raw.close()
        f_tof.close()
        print(f"stopped: S0={counts.get(0, 0)} S1={counts.get(1, 0)} states={states} errors={errors}", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
