# left2 보충 — 엎드림만 다시 (p1_left2_facedown, 10-26 13:23)
- 장치·자리 = left2 그대로(왼쪽, 몸 약 0.65 m, 기울기 그대로). `/api/placement` = left.
- 각본 `tools/real_protocol_left2_facedown.csv`: upright 30 s → face_down 60 s → upright 30 s. **단계마다 시작 직전 POST /api/reset**(guide.py --reset-host, PC 제안).
- 라벨: `labels_20261026_132307.csv`(실제 시각), t0 = `protocol_start_20261026_132307.txt`. 형식은 left1·left2 와 같음(S0=A, S1=B, flip 없음).

## 결과 (보드 평활 판정, 단계 앞뒤 2 s 제외)
- upright(1): upright 85 %
- face_down(2): **misplaced 100 %, face_down 0 %**, P(face_down) 중앙 0.001 · 최대 0.005
- upright(3, 엎드림 뒤): misplaced 85 % — 단계 시작 리셋을 해도 엎드림 뒤 바르게가 misplaced 로 남음
- 엎드림 때 격자(150~1200 mm 칸 수, 위→아래): A [00001567], B [00000367] — 몸이 아래 3줄에만 걸림
→ 이 기울기에서는 엎드림이 모델이 배운 시야(위 3~5줄까지)에 들어오지 않음. **face_down conf ≥ 0.99 확인 불가(엎드림 판정 0 tick)**. 장치 앞을 더 들어 머리·상체가 위 줄에 들어오게 다시 맞춰야 함.
