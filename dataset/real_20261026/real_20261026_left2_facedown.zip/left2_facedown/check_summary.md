# 단계별 점검 — left2_facedown

- 녹화 1792988573–1792989060 (8.1분), S0 2325 프레임, S1 2319 프레임, state 4337줄
- S0 1.5 s 넘는 빈 구간 0개
- S1 1.5 s 넘는 빈 구간 0개

| 단계 | 라벨 | 상태 | 초 | S0 Hz | S1 Hz | 보드 판정(평활) 비율 | 일치 |
|---|---|---|---|---|---|---|---|
| 1 | upright | ok | 30 | 5.0 | 5.0 | upright 85%, misplaced 14%, away 1% | 85% |
| 2 | face_down | ok | 60 | 5.0 | 5.0 | misplaced 100% | 0% |
| 3 | upright | ok | 30 | 5.0 | 5.0 | misplaced 85%, upright 15% | 15% |

## 엎드림(face_down) 단계의 확신도 — 시연 프로파일 하한 0.99 확인용
- 평활 conf (판정이 face_down 인 tick): 표본 없음
- instant.conf (순간 판정이 face_down 인 tick): 표본 없음
- 단계 전체 tick 539 중 face_down 0%, face_down 이면서 conf ≥0.99 0%
