# 단계별 점검 — left2

- 녹화 1792987552–1792988431 (14.7분), S0 4230 프레임, S1 4237 프레임, state 8022줄
- S0 1.5 s 넘는 빈 구간 2개: +52s 6.2s, +394s 3.6s
- S1 1.5 s 넘는 빈 구간 2개: +52s 6.2s, +394s 3.8s

| 단계 | 라벨 | 상태 | 초 | S0 Hz | S1 Hz | 보드 판정(평활) 비율 | 일치 |
|---|---|---|---|---|---|---|---|
| 1 | away | ok | 30 | 4.9 | 5.0 | misplaced 100% | 0% |
| 2 | upright | ok | 60 | 4.9 | 4.9 | upright 96%, drowsy 4% | 96% |
| 4 | upright | ok | 30 | 4.7 | 4.7 | misplaced 100% | 0% |
| 5 | drowsy | ok | 60 | 4.7 | 4.7 | misplaced 100% | 0% |
| 6 | chin_rest | ok | 60 | 4.8 | 4.8 | misplaced 100% | 0% |
| 7 | recline | ok | 60 | 4.9 | 4.9 | recline 100% | 100% |
| 8 | lean_forward | ok | 60 | 4.8 | 4.8 | misplaced 100% | 0% |
| 9 | lean_forward | ok | 60 | 4.9 | 5.0 | misplaced 100% | 0% |
| 10 | upright | ok | 30 | 5.0 | 5.0 | misplaced 94%, drowsy 6% | 0% |

## 엎드림(face_down) 단계의 확신도 — 시연 프로파일 하한 0.99 확인용
- 평활 conf (판정이 face_down 인 tick): 표본 없음
- instant.conf (순간 판정이 face_down 인 tick): 표본 없음
