# 단계별 점검 — left

- 녹화 1792984438–1792986100 (27.7분), S0 7844 프레임, S1 7861 프레임, state 14741줄
- S0 1.5 s 넘는 빈 구간 3개: +375s 1.7s, +1285s 1.7s, +1625s 2.3s
- S1 1.5 s 넘는 빈 구간 3개: +375s 1.7s, +1285s 1.7s, +1625s 2.3s

| 단계 | 라벨 | 상태 | 초 | S0 Hz | S1 Hz | 보드 판정(평활) 비율 | 일치 |
|---|---|---|---|---|---|---|---|
| 1 | away | ok | 30 | 4.9 | 5.0 | recline 96%, misplaced 4% | 0% |
| 2 | upright | ok | 120 | 4.8 | 4.9 | upright 58%, misplaced 39%, drowsy 3% | 58% |
| 3 | lean_forward | ok | 60 | 5.0 | 5.0 | misplaced 100% | 0% |
| 4 | upright | ok | 30 | 4.9 | 4.9 | upright 56%, misplaced 44% | 56% |
| 5 | forward_head | ok | 60 | 4.5 | 4.5 | misplaced 100% | 0% |
| 6 | upright | ok | 30 | 4.3 | 4.3 | misplaced 100% | 0% |
| 7 | recline | ok | 60 | 4.8 | 4.8 | recline 90%, misplaced 10% | 90% |
| 8 | upright | ok | 30 | 4.9 | 4.9 | misplaced 100% | 0% |
| 9 | chin_rest | ok | 45 | 4.9 | 4.8 | misplaced 100% | 0% |
| 10 | chin_rest | ok | 45 | 4.9 | 4.9 | misplaced 100% | 0% |
| 11 | upright | ok | 30 | 4.9 | 4.9 | misplaced 100% | 0% |
| 12 | face_down | ok | 60 | 4.9 | 4.9 | misplaced 100% | 0% |
| 13 | upright | ok | 30 | 5.0 | 5.0 | misplaced 64%, upright 36% | 36% |
| 14 | drowsy | ok | 90 | 4.9 | 4.9 | misplaced 100% | 0% |
| 15 | away | ok | 30 | 4.2 | 4.2 | misplaced 100% | 0% |
| 16 | upright | ok | 30 | 4.8 | 5.0 | misplaced 84%, recline 11%, upright 5% | 5% |
| 19 | upright | excluded_user | 30 | 4.9 | 4.9 | misplaced 100% | 0% |
| 20 | upright | ok | 60 | 5.0 | 5.0 | misplaced 100% | 0% |
| 21 | lean_forward | ok | 60 | 4.9 | 4.9 | misplaced 100% | 0% |
| 22 | upright | ok | 30 | 4.5 | 4.6 | misplaced 100% | 0% |

## 엎드림(face_down) 단계의 확신도 — 시연 프로파일 하한 0.99 확인용
- 평활 conf (판정이 face_down 인 tick): 표본 없음
- instant.conf (순간 판정이 face_down 인 tick): 표본 없음
- 단계 전체 tick 511 중 face_down 0%, face_down 이면서 conf ≥0.99 0%
