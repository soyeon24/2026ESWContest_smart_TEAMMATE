"""Per-step sanity check of a guided recording (2026-10-26): frames per sensor, gaps, board label mix, face_down conf.

    python -X utf8 check_session.py ../left
Writes <dir>/check_summary.md and prints it.
"""
from __future__ import annotations

import collections
import csv
import glob
import json
import os
import statistics
import sys


def main() -> int:
    d = sys.argv[1]
    steps = [r for r in csv.DictReader(open(glob.glob(os.path.join(d, "steps_*.csv"))[0], encoding="utf-8"))]
    raw = collections.defaultdict(list)     # sid -> [(t, ts_ms)]
    states = []                              # (t, posture, conf, instant_conf, online)
    for line in open(os.path.join(d, "rec_raw.jsonl"), encoding="utf-8"):
        try:
            o = json.loads(line)
        except ValueError:
            continue
        if o.get("kind") == "raw":
            raw[o["sensor"]["id"]].append((o["host_t"], o["sensor"].get("ts_ms")))
        elif o.get("kind") == "state":
            s = o["state"]
            inst = s.get("instant") or {}
            states.append((o["host_t"], s.get("posture"), s.get("conf"), inst.get("conf"), inst.get("posture"),
                           s.get("online_sensors"), s.get("valid")))
    out = ["# 단계별 점검 — " + os.path.basename(os.path.abspath(d)), ""]
    span = [t for v in raw.values() for t, _ in v]
    out.append(f"- 녹화 {min(span):.0f}–{max(span):.0f} ({(max(span) - min(span)) / 60:.1f}분), "
               + ", ".join(f"S{k} {len(v)} 프레임" for k, v in sorted(raw.items())) + f", state {len(states)}줄")
    for sid, v in sorted(raw.items()):
        gaps = [(a[0], b[0] - a[0]) for a, b in zip(v, v[1:]) if b[0] - a[0] > 1.5]
        out.append(f"- S{sid} 1.5 s 넘는 빈 구간 {len(gaps)}개" + (": " + ", ".join(f"+{g[0] - min(span):.0f}s {g[1]:.1f}s" for g in gaps[:12]) if gaps else ""))
    out += ["", "| 단계 | 라벨 | 상태 | 초 | S0 Hz | S1 Hz | 보드 판정(평활) 비율 | 일치 |", "|---|---|---|---|---|---|---|---|"]
    fd_conf, fd_inst = [], []
    for r in steps:
        if r["status"] not in ("ok", "excluded_user"):
            continue
        a, b = float(r["start_epoch"]), float(r["end_epoch"])
        dur = b - a
        hz = {sid: sum(1 for t, _ in v if a <= t < b) / dur if dur else 0 for sid, v in raw.items()}
        win = [s for s in states if a + 2 <= s[0] < b - 2]          # same 2 s margin as the scorer
        mix = collections.Counter(s[1] for s in win)
        n = sum(mix.values()) or 1
        top = ", ".join(f"{k} {v / n:.0%}" for k, v in mix.most_common(3))
        match = mix.get(r["label"], 0) / n
        out.append(f"| {r['step']} | {r['label']} | {r['status']} | {dur:.0f} | {hz.get(0, 0):.1f} | {hz.get(1, 0):.1f} | {top} | {match:.0%} |")
        if r["label"] == "face_down" and r["status"] == "ok":
            fd_conf += [s[2] for s in win if s[1] == "face_down" and s[2] is not None]
            fd_inst += [s[3] for s in win if s[4] == "face_down" and s[3] is not None]
            fd_all = [s for s in win]
    out.append("")

    def dist(xs, name):
        if not xs:
            return f"- {name}: 표본 없음"
        xs = sorted(xs)
        p10 = xs[max(0, int(len(xs) * 0.1) - 1)]
        return (f"- {name}: n={len(xs)} 중앙 {statistics.median(xs):.3f} · p10 {p10:.3f} · 최소 {xs[0]:.3f} · "
                f"≥0.99 {sum(1 for x in xs if x >= 0.99) / len(xs):.0%}")
    out.append("## 엎드림(face_down) 단계의 확신도 — 시연 프로파일 하한 0.99 확인용")
    out.append(dist(fd_conf, "평활 conf (판정이 face_down 인 tick)"))
    out.append(dist(fd_inst, "instant.conf (순간 판정이 face_down 인 tick)"))
    try:
        n_all = len(fd_all)
        n_fd = sum(1 for s in fd_all if s[1] == "face_down")
        n_fd99 = sum(1 for s in fd_all if s[1] == "face_down" and (s[2] or 0) >= 0.99)
        out.append(f"- 단계 전체 tick {n_all} 중 face_down {n_fd / n_all:.0%}, face_down 이면서 conf ≥0.99 {n_fd99 / n_all:.0%}")
    except NameError:
        pass
    text = "\n".join(out) + "\n"
    open(os.path.join(d, "check_summary.md"), "w", encoding="utf-8").write(text)
    print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
