# 안내 자세 녹화 10-26 — 왼쪽 자리 (p1_left)

- 사람 1명(p1), 장치 = 사람 기준 **왼쪽 약 30°**, 거리 "적당한 거리"(사용자 말, 실측 cm 미기록 — 정면 70~80 cm 기준으로 놓았다고 보면 됨).
- 보드: Pi 4 hub c3441f4(demo-b), 자세 서비스 placement-candidate(a3ff1cb) + opt_l8_c256, `/api/placement` = left.
- 녹화 방식: hub 가 ESP32 시리얼을 쓰므로 tof_live --record 대신 노트북이 `:8772/raw`(두 센서 0x05 최신 프레임)와
  `:8771/api/state` 를 10 Hz 로 받아 저장(`tools/record_board.py`).

## 파일
| 파일 | 내용 |
|---|---|
| `rec_raw.jsonl` | 원본 그대로. 첫 줄 `kind:"meta"`(model flip_rows/flip_cols = "auto"), `kind:"raw"` = /raw 의 센서 객체(frame_seq 로 중복 제거), `kind:"state"` = /api/state |
| `rec_toflines.jsonl` | real_from_record.py 가 그대로 읽는 tof_live 형식 `{"host_t","port":"S0"/"S1","raw":"F,<ts_ms>,<64 dist>,<64 status>"}`. S0 = 센서 A(왼쪽), S1 = B(오른쪽) |
| `protocol_start_20261026_121415.txt` | protocol_timer.py 형식, 첫 줄 = t0(첫 단계 시작 epoch) |
| `labels_20261026_121415.csv` | **실제 수행 시각 기준** 라벨(start_s,end_s,label,what — t0 기준). 명목 각본 대신 이걸 `--labels` 로 |
| `steps_20261026_121415.csv` | 단계별 실제 시작·끝 epoch 와 상태 |
| `check_summary.md` | 단계별 프레임·빈 구간·보드 판정 비율 |
| `../tools/real_protocol_v1_book.csv` | 각본(= PC real_protocol_v1_book.csv 와 같은 행) |

## 방향
- `/raw` 의 dist_mm 는 펌웨어가 0x05 flags(flip_rows=true, flip_cols=false)를 적용해 보낸 값 그대로. **추가 flip 없이** 채점.

## 진행 중 생긴 일 (라벨에 반영됨)
- 12단계 face_down: 첫 시도는 중단(aborted), 두 번째 시도만 ok.
- 17·18단계(misplaced — 장치 돌리기·뒤집기): **건너뜀**. 보드 전원이 불안정해 장치를 못 옮김. 나중에 따로 녹화 예정.
- 19단계(upright): 사용자 요청으로 **채점 제외**(잘못 누름). 라벨 파일에서 뺐고 steps 에는 `excluded_user`.
- 21단계(공책 필기, lean_forward): 중간에 사람 뒤로 다른 사람이 지나감(배경 약 3 m). 판정 비율엔 변화 없었음 — 필요하면 이 단계만 빼고 채점.
- 빈 구간(1.5 s 초과) 3개: +375 s 1.7 s, +1285 s 1.7 s, +1625 s 2.3 s — 노트북 Wi-Fi 지연(보드는 계속 동작).
- 앞선 두 시도(`attempt1_1206`, `attempt2_121200`)는 사용자가 처음부터 다시 하자고 해서 버린 것. 채점에 쓰지 말 것.

## 보드 판정 (평활, 각 단계 앞뒤 2 s 제외) — 왼쪽 자리에서는 거의 전부 misplaced
- upright 맞춤: 2단계 58 %, 4단계 56 %, 13단계 36 %. recline 7단계 90 %. 나머지 단계는 misplaced 100 % 에 가깝다.
- face_down 단계(12) 동안 face_down 판정 0 % → **확신도 0.99 하한 확인 불가**(이 자리에서는 face_down 자체가 안 나옴).
- 원본 격자: 사람이 센서 왼쪽 3~4 열(약 600 mm)에만 잡히고 나머지 열은 뒤 벽(약 3 m). 150 mm 안쪽 가림막 없음. 유효 픽셀 21~45/64.
  → 왼쪽 30° 자리에서 장치가 정면을 보고 있으면 사람이 시야 가장자리에 걸려 misplaced 로 읽히는 것으로 보임. 장치를 사람 쪽으로 돌려 놓을지(설치 안내) 판단 필요.
