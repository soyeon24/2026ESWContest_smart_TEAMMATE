# 안내 자세 녹화 10-26 — 왼쪽 다시 (p1_left2, 짧은 각본)

- 장치 왼쪽(left1 과 같은 자리), PC 진단(가깝고 아래로 기움)에 따라 거리·기울기 고쳐서 다시. `/api/placement` = left.
- 설정 점검(녹화 직전, tools/aim_check.py): 몸 약 0.6~0.7 m, 맨 위 2줄 머리 0~0.3, 보드 upright 대부분 — 총괄이 "이 정도면 진행" 으로 판단.
  바르게 2단계에서 A rows[00333344] 0.69 m · B rows[00345678] 0.65 m (left1: 몸 0.555 m, 머리 0.14).
- 보드: hub c3441f4(demo-b), 자세 서비스 placement-candidate + opt_l8_c256.
- 각본: `tools/real_protocol_left2_short.csv`(10단계 약 9분: away·upright·face_down·upright·drowsy·chin_rest·recline·lean_forward·필기 lean_forward·upright).

## 파일
| 파일 | 내용 |
|---|---|
| `rec_raw.jsonl` | 원본(첫 줄 meta flip=auto, /raw 센서 객체 frame_seq 중복 제거, /api/state) |
| `rec_toflines.jsonl` | real_from_record.py 용 tof_live 형식, S0 = A(왼쪽) · S1 = B(오른쪽), **flip 없이** |
| `protocol_start_20261026_130558.txt` | t0 |
| `labels_20261026_130558.csv` | 실제 시각 라벨 — 사용자가 마친 단계만(**face_down 없음**, 아래 참고) |
| `labels_20261026_130558_with_facedown.csv` | 위 + 3단계 face_down 첫 시도(60 s, 사용자가 r 로 되돌렸던 것)를 넣은 판 |
| `steps_20261026_130558.csv`, `check_summary.md` | 단계 기록, 단계별 점검 |

## 진행 중 생긴 일
- 3단계 face_down 을 한 번 끝낸 뒤 사용자가 r 로 되돌렸고, 다시 하지 않고 s 로 건너뜀 → 기본 라벨에는 face_down 이 없다.
  첫 시도 데이터는 녹화에 그대로 있어 `_with_facedown` 라벨에 넣었다(사용자가 되돌린 이유는 미확인 — 화면 판정을 보고 다시 하려던 것으로 보임).
- 4단계 upright 첫 시도도 되돌림(그 뒤 두 번째 시도 ok).
- 빈 구간: +52 s 6.2 s(단계 사이, 라벨 밖), +394 s 3.6 s(4단계 30 s 안) — 노트북 Wi-Fi.

## 보드 판정 첫 비교 (평활, 단계 앞뒤 2 s 제외)
| 단계 | 라벨 | left2 보드 | left1 보드 |
|---|---|---|---|
| 2 | upright | **upright 96 %** | upright 58 % |
| 3 | face_down (첫 시도) | recline 71 %, misplaced 29 %, **face_down 0 %** | misplaced 100 % |
| 4 | upright | misplaced 100 % | upright 56 % |
| 5 | drowsy | misplaced 100 % | misplaced 100 % |
| 6 | chin_rest | misplaced 100 % | misplaced 100 % |
| 7 | recline | **recline 100 %** | recline 90 % |
| 8·9 | lean_forward(타이핑·필기) | misplaced 100 % | misplaced 100 % |
| 10 | upright | misplaced 94 % | — |

- 바르게(2단계)는 고친 설정에서 크게 좋아졌다(58 → 96 %).
- **face_down 0 %** — 엎드리면 몸이 A 아래 3줄(0.52 m)·B 아래 2줄에만 잡힘 → 이 자리·기울기에서는 여전히 엎드림을 못 봄.
  그래서 "실기 face_down conf ≥ 0.99" 는 이번에도 **판정 불가**(face_down tick 0개).
- 엎드림 뒤의 upright(4·10단계)는 격자 행 분포가 2단계와 거의 같은데(A rows[00233335] vs [00333344]) misplaced 로 읽혔다.
  GRU 상태가 엎드림/기댐 뒤 misplaced 쪽에 머무는 이력 효과일 수 있음(보드 리셋 주기·자리비움 리셋 둘 다 0) — PC 채점 때 확인 요망.
