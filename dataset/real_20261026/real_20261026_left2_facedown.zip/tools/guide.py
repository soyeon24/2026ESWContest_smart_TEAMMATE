"""안내 자세 녹화 가이드 (2026-10-26). record_board.py 를 먼저 켜 두고 이 창에서 실행한다.

    python -X utf8 guide.py --protocol real_protocol_v1_plus_study.csv --out ../front_75cm --name p1_front75cm

단계마다 할 자세를 보여 주고, 10초 카운트다운(기본) 또는 Enter 를 기다린 뒤 정해진 시간 동안 유지 시간을 센다.
키:  Enter = 지금 시작   m = 카운트다운/Enter 대기 전환   r = 다시(유지 중이면 이 단계, 대기 중이면 앞 단계)
     s = 이 단계 건너뛰기   q = 끝내기

남기는 파일(--out 폴더):
  protocol_start_<시각>.txt   protocol_timer.py 와 같은 형식(첫 줄 = 첫 단계 시작 epoch)
  steps_<시각>.csv            실제로 한 단계별 시작·끝 epoch 와 상태(ok/redone/aborted/skipped)
  labels_<시각>.csv           real_from_record.py --labels 용 (start_s,end_s,label,what — t0 기준 초, ok 단계만).
                              단계 사이 이동 시간은 라벨이 없어 채점에서 빠진다.
"""
from __future__ import annotations

import argparse
import csv
import os
import sys
import time

try:
    import msvcrt  # Windows
except ImportError:  # pragma: no cover
    msvcrt = None


def beep(n: int = 1, freq: int = 1200) -> None:
    try:
        import winsound
        for _ in range(n):
            winsound.Beep(freq, 160)
            time.sleep(0.06)
    except Exception:
        sys.stdout.write("\a" * n)
        sys.stdout.flush()


def read_rows(path: str):
    rows = []
    with open(path, encoding="utf-8-sig") as fp:
        for r in csv.reader(fp):
            if not r or r[0].strip().startswith("#") or r[0].strip() == "start_s":
                continue
            a, b = float(r[0]), float(r[1])
            rows.append((a, b - a, r[2].strip(), (r[3].strip() if len(r) > 3 else r[2].strip())))
    rows.sort()
    return [(lab, dur, what) for _, dur, lab, what in rows]


def key() -> str | None:
    if msvcrt is None or not msvcrt.kbhit():
        return None
    ch = msvcrt.getwch()
    if ch in ("\x00", "\xe0"):
        msvcrt.getwch()
        return None
    if ch in ("\r", "\n"):
        return "enter"
    return ch.lower()


def status_line(path: str | None) -> str:
    if not path or not os.path.exists(path):
        return "녹화 상태: (상태 파일 없음 - record_board.py 가 켜져 있는지 확인)"
    try:
        txt = open(path, encoding="utf-8").read().strip()
        age = time.time() - os.path.getmtime(path)
        warn = "  ※ 상태가 오래됨 - 녹화가 멈췄을 수 있음" if age > 12 else ""
        return f"녹화 상태: {txt}{warn}"
    except Exception as exc:
        return f"녹화 상태: 읽기 실패 {exc}"


def main() -> int:
    try:
        sys.stdout.reconfigure(errors="replace")
    except Exception:
        pass
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--protocol", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--name", default="")
    ap.add_argument("--status", default=None, help="record_board.py 의 <out>_status.txt")
    ap.add_argument("--countdown", type=int, default=10)
    ap.add_argument("--mode", choices=["countdown", "enter"], default="enter")
    ap.add_argument("--enter-delay", type=int, default=3, help="Enter 를 누른 뒤 시작까지 초")
    ap.add_argument("--start-at", type=int, default=1, help="이 단계 번호부터 (1부터)")
    ap.add_argument("--reset-host", default="", help="주면 단계마다 시작 직전에 POST http://<host>:8771/api/reset (보드 GRU 상태 비움, PC 10-26 제안)")
    args = ap.parse_args()

    steps = read_rows(args.protocol)
    os.makedirs(args.out, exist_ok=True)
    mode = args.mode
    t0: float | None = None
    stamp = time.strftime("%Y%m%d_%H%M%S")
    start_file = os.path.join(args.out, f"protocol_start_{stamp}.txt")
    steps_file = os.path.join(args.out, f"steps_{stamp}.csv")
    labels_file = os.path.join(args.out, f"labels_{stamp}.csv")
    attempts: list[dict] = []          # every attempt, in order

    def save() -> None:
        with open(steps_file, "w", encoding="utf-8", newline="") as fp:
            w = csv.writer(fp)
            w.writerow(["step", "label", "what", "start_epoch", "end_epoch", "status"])
            for a in attempts:
                w.writerow([a["step"], a["label"], a["what"], f"{a['start']:.3f}", f"{a['end']:.3f}", a["status"]])
        if t0 is None:
            return
        with open(labels_file, "w", encoding="utf-8", newline="") as fp:
            fp.write(f"# {args.name} - 실제 수행 시각 기준 라벨 (t0 = {start_file} 첫 줄). 단계 사이는 라벨 없음 = 채점 제외\n")
            w = csv.writer(fp)
            w.writerow(["start_s", "end_s", "label", "what"])
            for a in attempts:
                if a["status"] == "ok":
                    w.writerow([f"{a['start'] - t0:.2f}", f"{a['end'] - t0:.2f}", a["label"], a["what"]])

    total = sum(d for _, d, _ in steps)
    print("=" * 70)
    print(f"안내 자세 녹화 · {args.name} · {len(steps)} 단계 · 유지 시간 합 {total / 60:.1f}분")
    print("키: Enter 지금 시작 · m 카운트다운/Enter 전환 · r 다시 · s 건너뛰기 · q 끝내기")
    print(status_line(args.status))
    print("=" * 70)

    i = max(0, args.start_at - 1)
    try:
        while i < len(steps):
            label, dur, what = steps[i]
            nxt = steps[i + 1][2] if i + 1 < len(steps) else "끝"
            print()
            print("#" * 70)
            print(f"  [{i + 1}/{len(steps)}]  {what}")
            print(f"  라벨 {label} · {dur:.0f}초 유지 · 다음: {nxt}")
            print("  " + status_line(args.status))
            print("#" * 70)
            beep(1, 900)
            # ---- wait ----
            action = None
            if mode == "countdown":
                print(f"  {args.countdown}초 뒤 시작 (Enter = 바로, m = Enter 대기로)", flush=True)
                end_wait = time.time() + args.countdown
                shown = None
                while action is None:
                    left = int(end_wait - time.time() + 0.999)
                    if left <= 0:
                        action = "start"
                        break
                    if left != shown:
                        shown = left
                        print(f"    {left} ...", flush=True)
                        if left <= 3:
                            beep(1, 1000)
                    k = key()
                    if k == "enter":
                        action = "start"
                    elif k == "m":
                        mode = "enter"
                        print("  → Enter 대기 모드. 준비되면 Enter.", flush=True)
                        break
                    elif k in ("r", "s", "q"):
                        action = k
                    time.sleep(0.05)
            if action is None:   # enter mode: Enter, then --enter-delay s
                print(f"  준비되면 Enter → {args.enter_delay}초 뒤 시작 (m = {args.countdown}초 카운트다운 모드로)", flush=True)
                while action is None:
                    k = key()
                    if k == "enter":
                        for left in range(args.enter_delay, 0, -1):
                            print(f"    {left} ...", flush=True)
                            beep(1, 1000)
                            time.sleep(1)
                        action = "start"
                    elif k == "m":
                        mode = "countdown"
                        print(f"  → 카운트다운 모드(다음 단계부터 {args.countdown}초). 이번 단계는 Enter.", flush=True)
                    elif k in ("r", "s", "q"):
                        action = k
                    time.sleep(0.05)
            if action == "q":
                break
            if action == "s":
                now = time.time()
                attempts.append({"step": i + 1, "label": label, "what": what, "start": now, "end": now, "status": "skipped"})
                save()
                i += 1
                continue
            if action == "r":
                prev = next((a for a in reversed(attempts) if a["status"] == "ok"), None)
                if prev is not None:
                    prev["status"] = "redone"
                    save()
                    i = prev["step"] - 1
                    print(f"  ↩ {prev['step']}단계를 다시 합니다.", flush=True)
                continue
            # ---- hold ----
            reset_note = ""
            if args.reset_host:
                try:
                    import urllib.request
                    req = urllib.request.Request(f"http://{args.reset_host}:8771/api/reset", data=b"", method="POST")
                    urllib.request.urlopen(req, timeout=1.5).read()
                    reset_note = f" · 보드 GRU 리셋 {time.time():.3f}"
                except Exception as exc:
                    reset_note = f" · 보드 리셋 실패({exc})"
            start = time.time()
            if t0 is None:
                t0 = start
                with open(start_file, "w", encoding="utf-8") as fp:
                    fp.write(f"{t0:.4f}\n# protocol {os.path.abspath(args.protocol)}\n# name {args.name}\n"
                             f"# guided: real per-step times in {os.path.basename(steps_file)} / {os.path.basename(labels_file)}\n")
            beep(2, 1300)
            print(f"  ▶ 시작 - {what}  ({dur:.0f}초)   r = 이 단계 다시 · q = 끝{reset_note}", flush=True)
            aborted = None
            end_hold = start + dur
            shown = None
            while True:
                left = int(end_hold - time.time() + 0.999)
                if left <= 0:
                    break
                if left != shown and (left % 10 == 0 or left <= 5):
                    shown = left
                    print(f"    남은 {left}초", flush=True)
                k = key()
                if k in ("r", "q"):
                    aborted = k
                    break
                time.sleep(0.05)
            end = time.time()
            if aborted:
                attempts.append({"step": i + 1, "label": label, "what": what, "start": start, "end": end, "status": "aborted"})
                save()
                if aborted == "q":
                    break
                print("  ↩ 이 단계를 다시 합니다.", flush=True)
                continue
            attempts.append({"step": i + 1, "label": label, "what": what, "start": start, "end": end, "status": "ok"})
            save()
            beep(1, 1500)
            print("  ■ 끝", flush=True)
            i += 1
    except KeyboardInterrupt:
        pass
    save()
    if t0 is not None:
        with open(start_file, "a", encoding="utf-8") as fp:
            fp.write(f"# stopped_at {time.time() - t0:.1f} s\n")
    ok = sum(1 for a in attempts if a["status"] == "ok")
    print()
    print("=" * 70)
    print(f"끝. 완료 {ok}/{len(steps)} 단계. 파일: {steps_file}")
    print(f"      {labels_file}\n      {start_file}")
    print("이 창은 닫아도 됩니다. 녹화(record_board.py)는 Claude 가 멈춥니다.")
    print("=" * 70)
    return 0


if __name__ == "__main__":
    sys.exit(main())
